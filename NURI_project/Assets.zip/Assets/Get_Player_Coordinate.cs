//このスクリプトでは各コートから一番浅い点の座意表を求めます。前段階でコートは分割されているので幅の数値が少し異なります。
//スタート画面などで各プレイヤーの座標が必要となる場合はここの変数を外部参照することになるでしょう。
//一番浅くなる座標がおそらく複数出てくることになるのでx,y座標ともに平均値を出すアルゴリズムにしています。

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Get_Player_Coordinate : MonoBehaviour
{
    Divide_Array Divide_Array;
    private ushort[] Right_Cort;//入れ物
    private ushort[] Left_Cort;//入れ物

    private int Cort_Width;
    private int Cort_Height;

    public int player1_x;
    public int player1_y;
    public int player2_x;
    public int player2_y;

    
    // Start is called before the first frame update
    void Start()
    {
        Cort_Width=256;//半分のコートの幅
        Cort_Height=424;//半分のコートの幅
    }

    // Update is called once per frame
    int cnt;//これを使ってタイムラグをなくしている。変更の余地ありあり
    void Update()
    {
        //中点を求めるために定義しています
        int player1_Min_Sum_x=0;
        int player1_Min_Sum_y=0;
        int player2_Min_Sum_x=0;
        int player2_Min_Sum_y=0;
        int player1_counter=0;
        int player2_counter=0;

         if (cnt < 150) 
        { 
            cnt++; 
            return; 
        } 
         Divide_Array= GetComponent<Divide_Array>();
         Right_Cort=Divide_Array.Right_Cort;
         Left_Cort=Divide_Array.Left_Cort;

         int player1_Min=Right_Cort.Min();
         int player2_Min=Left_Cort.Min();

    

         for(int x=0; x<Cort_Width;x++){
            for(int y=0;y<Cort_Height;y++){
                if(Right_Cort[x+y*Cort_Width]==player1_Min){
                    player1_Min_Sum_x+=x;
                    player1_Min_Sum_y+=y;
                    player1_counter+=1;
                   
                }
                if(Left_Cort[x+y*Cort_Width]==player2_Min){
                    player2_Min_Sum_x+=x;
                    player2_Min_Sum_y+=y;
                    player2_counter+=1;
                }
            }
         }

         player1_x=player1_Min_Sum_x/player1_counter;
         player2_x=player2_Min_Sum_x/player2_counter;

         player1_y=player1_Min_Sum_y/player1_counter;
         player2_y=player2_Min_Sum_y/player2_counter;    

    }
}
