///テスト用に作った4×4ピクセルの画像のDepthデータを保持している配列を作るスクリプトです。必要があれば実験に使ってください///


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test_case : MonoBehaviour
{
    public ushort[] _Data;
    public ushort[] GetData()
    {
        return _Data;
    }
    // Start is called before the first frame update
    void Start()
    {
       
    }
    

    // Update is called once per frame
    void Update()
    {
         _Data= new ushort[217088];
        for(int i=0;i<217088;i++){
        ushort random=(ushort)Random.Range(2, 3000);
        _Data[i]=random;
        }
      
     
    }
}
