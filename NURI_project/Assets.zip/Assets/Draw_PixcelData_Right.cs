/*もともと用意している画像のpixcelデータを置き換えすることができるスクリプトです。アイテムなどを作成する場合にはこちらのスクリプトを参照することになるとは思います。
塗りに使う仕組みを変更する場合には少しプログラムを変える必要があると思います。
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Draw_PixcelData_Right : MonoBehaviour
 {
    Get_Player_Coordinate Get_Player_Coordinate;
    Texture2D drawTexture ;
    Color[] buffer;

    private int player1_x;
    private int player1_y;

    void Start () {
        
        //脳死で使っていいやつ。とりあえずstartに書きましょう//////////////////////////////////////////////////
        Texture2D mainTexture = (Texture2D) GetComponent<Renderer> ().material.mainTexture;             ////
        Color[] pixels = mainTexture.GetPixels();                                                       ////
        buffer = new Color[pixels.Length];                                                              ////
        pixels.CopyTo (buffer, 0);                                                                      ////
        drawTexture = new Texture2D (mainTexture.width, mainTexture.height, TextureFormat.RGBA32, false);///
        drawTexture.filterMode = FilterMode.Point;                                                      ////
        ///ここまでは脳死ゾーン。変更しないでください。////////////////////////////////////////////////////////
    }
    int cnt;

    void Update () 
    {
        ///////↓変更の余地があると思われるゾーン。アイテムなど加える場合にはここを書き換えることになると思います。/////////////////

        //Array_conberter（script)のGetData[]の値を参照して変数に入れてる。使うときはArray_1_OR_2を呼び出すようにすればOK。
        Get_Player_Coordinate= GameObject.Find("GameObject").GetComponent<Get_Player_Coordinate>();
        player1_x=Get_Player_Coordinate.player1_x;
        player1_y=Get_Player_Coordinate.player1_y;


        //ピクセルデータを置き換えるスクリプト//////////////
        for(int x = 0; x < drawTexture.width; x++){
            for(int y = 0; y <drawTexture.height; y++){
                if((new Vector2(player1_x,player1_y)-new Vector2(x,y)).magnitude<10){
                    buffer.SetValue (Color.green, x + 256 * y);
                }
            }
        }

        ///////↑変更するならココ！！↑//////////////////////////////////////////////////////////////////////////////////////////




        //書き換えたピクセルを描画してくれています。そっとしておきましょう//
        drawTexture.SetPixels (buffer);                             ////
        drawTexture.Apply ();                                       ////
        GetComponent<Renderer> ().material.mainTexture = drawTexture;///
        ///ここまではそっとしておいてほしいゾーン//////////////////////////
    }
}


