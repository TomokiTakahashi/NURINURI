using System; 
using System.Collections; 
using System.Collections.Generic; 
using System.Linq; 
using System.Threading; 
using UnityEngine; 
using Windows.Kinect; 


public class DepthManager : MonoBehaviour 
{ 
    private KinectSensor _sensor; 
    private MultiSourceFrameReader _reader; 
    private CoordinateMapper _mapper; 

    public ushort[] _depthData; //16ビットの符号なしデータ 
    private ushort maxDepthArray;//配列中の最大値 

    private float maxDepthArrayIndex;//配列の最大値の添え字 
    public ushort[] unityPoints;//unityで使用する座標の配列 

    public FrameDescription DepthFrameDesc { get; private set; } //深度の情報 




    // Start is called before the first frame update 
    void Start() 
    { 
        _sensor = KinectSensor.GetDefault(); 

        if (_sensor == null) return; 
        _reader = _sensor.OpenMultiSourceFrameReader(FrameSourceTypes.Depth); 
        // 新しいフレームが取得された時に実行される関数の追加 
        _reader.MultiSourceFrameArrived += OnMultiSourceFrameArrived; 
        _mapper = _sensor.CoordinateMapper; 
        DepthFrameDesc = _sensor.DepthFrameSource.FrameDescription; //デプスに関するの情報を持つ 

       
        // 配列の初期化 
        _depthData = new ushort[DepthFrameDesc.LengthInPixels];//距離画像の配列を初期化 
        maxDepthArray = 60000; 

        if (!_sensor.IsOpen) { 
            _sensor.Open(); 
        } 

    } 

    //動作が終ったとき 
    private void OnApplicationQuit() 
    { 
        _reader?.Dispose(); 
        if (_sensor != null && _sensor.IsOpen) { 
            _sensor.Close(); 
        } 
    } 

 
    private void OnMultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e) 
    { 
        var frame = e.FrameReference.AcquireFrame(); 
        if (frame == null) return; 
        // usingは関数の最後に自動的にDispose()を呼び出す。depthFrame.Dispose()の必要なし。 
        using var depthFrame = frame.DepthFrameReference.AcquireFrame(); 
        // 深度データの取得 
        depthFrame.CopyFrameDataToArray(_depthData); //自作の配列に距離画像のフレームデータをコピーしている 
    } 

    private void Update() 
    { 


        for (int i = 0; i < 217088; i++) 
        { 
            if(_depthData[i]<300){
                _depthData[i]=10000;
            }
        } 


    } 
} 