//各コートから深度が最も浅い座標を取り出すために配列を左右に分割するスクリプトです。特にいじるところはないと思います。処理の速度次第ではlinqを使ったコードに書き換えるつもりです。

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Divide_Array : MonoBehaviour
{
    DepthManager DepthManager;
    Test_case Test_case;
    public ushort[] Right_Cort;//入れ物
    public ushort[] Left_Cort;//入れ物
    private ushort[] a;


    int Texture_Width=512;//ここをdepthmanagerから与えらるデータの幅に変えるおそらく512
    int Texture_Height=424;//ここをdepthmanagerから与えらるデータの幅に変えるおそらく424

   
    // Start is called before the first frame update
    int cnt;
    void Start()
    {

    }
    // Update is called once per frame
    
    void Update()
    { 
        
        
        a =new ushort[217088];//tukkomi
        Right_Cort =new ushort[108544];
        Left_Cort =new ushort[108544];

        DepthManager=GetComponent<DepthManager>();//tukkomi
        a=DepthManager._depthData;

        /*Test_case= GetComponent<Test_case>();
        a=Test_case.GetData();*/
 
        
        //割と自信がない部分。変更が必要になるとすればここ。plinqを使うにも多分ココ
        for(int x = 0; x < Texture_Width; x++){
			for(int y = 0; y <Texture_Height; y++){
                if(x<Texture_Width/2){
                     Right_Cort[x+256*y]=a[x+512*y];
                }else{
                     Left_Cort[x+256*y-256]=a[x+512*y];
                }
            }
        }
    }
}

//lengthinpixelを使う